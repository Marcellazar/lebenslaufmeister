import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

export default function CVGenerator() {
  const [name, setName] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [experience, setExperience] = useState("");
  const [education, setEducation] = useState("");
  const [skills, setSkills] = useState("");
  const [languages, setLanguages] = useState("");
  const [generatedCV, setGeneratedCV] = useState("");
  const [loading, setLoading] = useState(false);

  const generateCV = async () => {
    setLoading(true);
    const prompt = `Erstelle einen professionellen Lebenslauf auf Deutsch basierend auf den folgenden Informationen:

Name: ${name}
Berufsziel: ${jobTitle}
Berufserfahrung: ${experience}
Ausbildung: ${education}
Fähigkeiten: ${skills}
Sprachen: ${languages}

Strukturiere den Lebenslauf übersichtlich in Abschnitte.`;

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });

      if (!response.ok) {
        throw new Error("Fehler beim Generieren des Lebenslaufs");
      }

      const data = await response.json();
      setGeneratedCV(data.result);
    } catch (error) {
      console.error(error);
      setGeneratedCV("Es gab einen Fehler beim Generieren des Lebenslaufs.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-4 space-y-6">
      <h1 className="text-2xl font-bold">CV Meister – KI-basierter Lebenslauf-Generator</h1>
      <Card>
        <CardContent className="space-y-4">
          <Input placeholder="Vor- und Nachname" value={name} onChange={(e) => setName(e.target.value)} />
          <Input placeholder="Berufsziel (z.B. Frontend-Entwickler)" value={jobTitle} onChange={(e) => setJobTitle(e.target.value)} />
          <Textarea placeholder="Berufserfahrung (Stichpunkte)" value={experience} onChange={(e) => setExperience(e.target.value)} />
          <Textarea placeholder="Ausbildung" value={education} onChange={(e) => setEducation(e.target.value)} />
          <Textarea placeholder="Fähigkeiten" value={skills} onChange={(e) => setSkills(e.target.value)} />
          <Textarea placeholder="Sprachen" value={languages} onChange={(e) => setLanguages(e.target.value)} />
          <Button onClick={generateCV} disabled={loading}>
            {loading ? "Generieren..." : "Lebenslauf generieren"}
          </Button>
        </CardContent>
      </Card>

      {generatedCV && (
        <Card>
          <CardContent>
            <h2 className="text-xl font-semibold mb-2">Dein Lebenslauf</h2>
            <pre className="whitespace-pre-wrap font-mono text-sm bg-gray-100 p-4 rounded-md">
              {generatedCV}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
